/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.t2_g1;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class ProfesorTiempoCompleto extends Docente{

    private double sueldo_fijo;
    private int inasistencias_injustificadas;
    private int tardanzas;

    public ProfesorTiempoCompleto() {
    }

    public ProfesorTiempoCompleto(double sueldo_fijo, int id_docente, String tipo_Documento, String nro_documento, String nombres, String apellido_paterno, String apellido_materno, String direccion, String telefono, LocalDate fecha_ingreso, DepartamentoAcademico departamento_actual, ArrayList<DepartamentoAcademico> historial_departamentos, String afp, String sistema_Pension) {
        super(id_docente, tipo_Documento, nro_documento, nombres, apellido_paterno, apellido_materno, direccion, telefono, fecha_ingreso, departamento_actual, historial_departamentos, afp, sistema_Pension);
        this.sueldo_fijo = sueldo_fijo;
        this.inasistencias_injustificadas = 0;
        this.tardanzas = 0;
    }

    public double getSueldo_fijo() {
        return sueldo_fijo;
    }

    public void setSueldo_fijo(double sueldo_fijo) {
        this.sueldo_fijo = sueldo_fijo;
    }

    public int getInasistencias_justificadas() {
        return inasistencias_injustificadas;
    }

    public void setInasistencias_justificadas(int inasistencias_justificadas) {
        this.inasistencias_injustificadas = inasistencias_justificadas;
    }

    public int getTardanzas() {
        return tardanzas;
    }

    public void setTardanzas(int tardanzas) {
        this.tardanzas = tardanzas;
    }
    
    public double calcularSueldo(){
        double sueldoMensual = 0;
        double tardanza = (this.sueldo_fijo/30)/2;
        double falta = (this.sueldo_fijo/30);
        sueldoMensual = this.sueldo_fijo - tardanza*this.tardanzas - falta * this.inasistencias_injustificadas;
        return sueldoMensual;
    }
    
    public void registrarTardanzaInasistencia(String info){
        if("Tardanza".equalsIgnoreCase(info)){
            this.tardanzas++;
            System.out.println("Tardanza agregada correctamente");
        }else if("Inasistencia".equalsIgnoreCase(info)){
            this.inasistencias_injustificadas++;
            System.out.println("Inasistencia agregada correctamente");
        }
    }
    
    public void limpiarTaranzasInasistencias(){
        this.tardanzas = 0;
        this.inasistencias_injustificadas = 0;
        System.out.println("Limpiado correctamente");
    }
}
