/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.t2_g1;

/**
 *
 * @author User
 */
public class T2_G1 {

    public static void main(String[] args)
    {
        System.out.println("Hello World!");
        
        
    }
}
