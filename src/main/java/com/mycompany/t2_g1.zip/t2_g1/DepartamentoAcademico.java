/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.t2_g1;

/**
 *
 * @author User
 */
public class DepartamentoAcademico {
    private String codigo;
    private String nombre;
    private String facultad;

    public DepartamentoAcademico() {
    }

    public DepartamentoAcademico(String codigo, String nombre, String facultad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.facultad = facultad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFacultad() {
        return facultad;
    }

    public void setFacultad(String facultad) {
        this.facultad = facultad;
    }
    
    public boolean esindependiente(){
        if (this.facultad.isEmpty()){
            return true;
        }
        return false;
    }
}
