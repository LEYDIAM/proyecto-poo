/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.t2_g1;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public abstract class Docente
{
    private int id_docente;
    private String tipo_Documento;
    private String nro_documento;
    private String nombres;
    private String apellido_paterno;
    private String apellido_materno;
    private String direccion;
    private String telefono;
    private LocalDate fecha_ingreso;
    private DepartamentoAcademico departamento_actual;
    private ArrayList<DepartamentoAcademico> historial_departamentos;
    private String afp;
    private String sistema_Pension;

    public Docente() {
    }

    public Docente(int id_docente, 
            String tipo_Documento, 
            String nro_documento, 
            String nombres, 
            String apellido_paterno, 
            String apellido_materno, 
            String direccion, 
            String telefono, 
            LocalDate fecha_ingreso, 
            DepartamentoAcademico departamento_actual, 
            ArrayList<DepartamentoAcademico> historial_departamentos, 
            String afp, 
            String sistema_Pension) {
        this.id_docente = id_docente;
        this.tipo_Documento = tipo_Documento;
        this.nro_documento = nro_documento;
        this.nombres = nombres;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.direccion = direccion;
        this.telefono = telefono;
        this.fecha_ingreso = fecha_ingreso;
        this.departamento_actual = departamento_actual;
        this.historial_departamentos = historial_departamentos;
        this.afp = afp;
        this.sistema_Pension = sistema_Pension;
    }

    public int getId_docente() {
        return id_docente;
    }

    public void setId_docente(int id_docente) {
        this.id_docente = id_docente;
    }

    public String getTipo_Documento() {
        return tipo_Documento;
    }

    public void setTipo_Documento(String tipo_Documento) {
        if ("DNI".equalsIgnoreCase(this.tipo_Documento) || "Carnet extranjeria".equalsIgnoreCase(this.tipo_Documento)) 
        {
            this.tipo_Documento = tipo_Documento;
        }else{
            System.out.println("Error, el tipo de carnet es invalido");
        }
    }

    public String getNro_documento() {
        return nro_documento;
    }

    public void setNro_documento(String nro_documento) {
        if (nro_documento.length()==8){
        this.nro_documento = nro_documento;
        }else{System.out.println("Error, la cantidad de valores es invalida");}
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellido_paterno() {
        return apellido_paterno;
    }

    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }

    public String getApellido_materno() {
        return apellido_materno;
    }

    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        if (nro_documento.length() == 9){
           this.telefono = telefono;
        }else{System.out.println("Error, la cantidad de valores es invalida");}
    }

    public LocalDate getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(LocalDate fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    public DepartamentoAcademico getDepartamento_actual() {
        return departamento_actual;
    }

    public void setDepartamento_actual(DepartamentoAcademico departamento_actual) {
        this.departamento_actual = departamento_actual;
    }

    public ArrayList<DepartamentoAcademico> getHistorial_departamentos() {
        return historial_departamentos;
    }

    public void setHistorial_departamentos(ArrayList<DepartamentoAcademico> historial_departamentos) {
        this.historial_departamentos = historial_departamentos;
    }

    public String getAfp() {
        return afp;
    }

    public void setAfp(String afp) {
        if("AFP".equalsIgnoreCase(this.sistema_Pension)){
            this.afp = afp;
        }else{
            System.out.println("El sistema de pensiones es ONP");
        }
    }

    public String getSistema_Pension() {
        return sistema_Pension;
    }

    public void setSistema_Pension(String sistema_Pension) {
        if("AFP".equalsIgnoreCase(this.sistema_Pension) || "ONP".equalsIgnoreCase(this.sistema_Pension)){
            this.sistema_Pension = sistema_Pension;
        }else{
            System.out.println("Ingrese un sistema de pension valido");
        }
    }
   
    public void rotarDepartamento(DepartamentoAcademico d)
    {
        try{
            //Se le asigna al parámetro
            this.departamento_actual = d;
            historial_departamentos.add(d);
        }catch(IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
    
    public void mostrarHistorial(){
        for(DepartamentoAcademico d : historial_departamentos){
            d.toString();
        }
    }
    
    @Override
    public String toString() {
        return "\n"
            + "╔══════════════════════════════════════════╗\n"
            + "║           DATOS DEL DOCENTE               ║\n"
            + "╠══════════════════════════════════════════╣\n"
            + "║ ID Docente          : " + id_docente + "\n"
            + "║ Tipo de documento   : " + tipo_Documento + "\n"
            + "║ Nro. de documento   : " + nro_documento + "\n"
            + "║ Nombres             : " + nombres + "\n"
            + "║ Apellido paterno    : " + apellido_paterno + "\n"
            + "║ Apellido materno    : " + apellido_materno + "\n"
            + "║ Dirección           : " + direccion + "\n"
            + "║ Teléfono            : " + telefono + "\n"
            + "║ Fecha de ingreso    : " + fecha_ingreso + "\n"
            + "╠══════════════════════════════════════════╣\n"
            + "║           DATOS LABORALES                ║\n"
            + "╠══════════════════════════════════════════╣\n"
            + "║ Historial departamentos: " + historial_departamentos + "\n"
            + "║ AFP                 : " + afp + "\n"
            + "║ Sistema de pensión  : " + sistema_Pension + "\n"
            + "╚══════════════════════════════════════════╝";
    }
}

