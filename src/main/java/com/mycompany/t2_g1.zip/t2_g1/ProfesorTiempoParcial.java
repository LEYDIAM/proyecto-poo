/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.t2_g1;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class ProfesorTiempoParcial extends Docente
{
    private double horas_dictada;
    private double tarifa_hora;

    public ProfesorTiempoParcial() {
    }

    public ProfesorTiempoParcial(double horas_Dictada, double tarifa_hora, int id_docente, String tipo_Documento, String nro_documento, String nombres, String apellido_paterno, String apellido_materno, String direccion, String telefono, LocalDate fecha_ingreso, DepartamentoAcademico departamento_actual, ArrayList<DepartamentoAcademico> historial_departamentos, String afp, String sistema_Pension) {
        super(id_docente, tipo_Documento, nro_documento, nombres, apellido_paterno, apellido_materno, direccion, telefono, fecha_ingreso, departamento_actual, historial_departamentos, afp, sistema_Pension);
        this.horas_dictada = horas_Dictada;
        this.tarifa_hora = tarifa_hora;
    }

    public double getHoras_Dictada() {
        return horas_dictada;
    }

    public void setHoras_Dictada(double horas_Dictada) {
        this.horas_dictada = horas_Dictada;
    }

    public double getTarifa_hora() {
        return tarifa_hora;
    }

    public void setTarifa_hora(double tarifa_hora) {
        this.tarifa_hora = tarifa_hora;
    }
    
    public double calcularSueldo(){
        double sueldoFinal = 0;
        sueldoFinal = this.tarifa_hora * this.horas_dictada;
        return sueldoFinal;
    }
    
}
